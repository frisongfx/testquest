﻿import cv2
import numpy as np


def testQuest(gabarito, prova):
    whitePixels = 0
    acertos = 10
    qstName = 1
    diff = np.array(cv2.subtract(gabarito, prova))
    diff = diff[180:560, 120:305]
    alt, larg = diff.shape
    tamQuest = alt // 10
    for sect in range(0, alt, tamQuest):
        print("\n--- Questão", qstName)
        quest = np.array(diff[sect:sect + tamQuest, 0:larg])
        altQuest, largQuest = quest.shape

        for pxLarg in range(0, largQuest, 1):
            for pxAlt in range(0, altQuest, 1):
                if quest[pxAlt, pxLarg] > 80:
                    whitePixels += 1
        print(whitePixels)
        if whitePixels >= 500:
            acertos -= 1
            print("Errou")
        else:
            print("Acertou")
        whitePixels = 0
        cv2.imshow("", quest)
        cv2.waitKey(1000)
        qstName += 1
    print("\nAcertou:", acertos)


def main():
    gabarito = cv2.imread("./gabs/fis/p7.jpeg", 0)
    prova = cv2.imread("./gabs/fis/p1.jpeg", 0)

    # ---------------------------------
    diff = cv2.subtract(gabarito, prova)
    cv2.imshow("", diff)
    cv2.waitKey(2000)
    # ---------------------------------

    testQuest(gabarito, prova)


main()
